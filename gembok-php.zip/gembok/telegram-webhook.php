<?php
/**
 * Telegram Webhook Direct Handler
 * Same level as install.php for easier access
 */

// Disable error display
ini_set('display_errors', 0);
error_reporting(E_ALL);
ini_set('log_errors', 1);

// Load CodeIgniter
define('FCPATH', __DIR__ . '/public/');
require_once __DIR__ . '/app/Config/Paths.php';
$paths = new Config\Paths();
require_once $paths->systemDirectory . '/bootstrap.php';

// Get webhook data
$input = file_get_contents('php://input');
$update = json_decode($input, true);

// Log incoming webhook for debugging
@file_put_contents(__DIR__ . '/writable/logs/telegram-webhook-' . date('Y-m-d') . '.log', 
    date('H:i:s') . " - " . $input . "\n", 
    FILE_APPEND
);

// If GET request (testing)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json');
    echo json_encode([
        'ok' => true,
        'status' => 'Telegram webhook is ready!',
        'endpoint' => $_SERVER['REQUEST_URI'],
        'method' => $_SERVER['REQUEST_METHOD'],
        'timestamp' => date('Y-m-d H:i:s'),
        'server_time' => time()
    ]);
    exit;
}

// If no data, return OK (Telegram might send test)
if (!$update) {
    header('Content-Type: application/json');
    echo json_encode(['ok' => true]);
    exit;
}

// Load required services
require_once __DIR__ . '/app/Services/ConfigService.php';
require_once __DIR__ . '/app/Services/TelegramService.php';
require_once __DIR__ . '/app/Services/MikrotikService.php';

use App\Services\TelegramService;
use App\Services\MikrotikService;
use App\Services\ConfigService;

try {
    $telegram = new TelegramService();
    $mikrotik = new MikrotikService();
    
    // Handle message
    if (isset($update['message'])) {
        $chatId = $update['message']['chat']['id'];
        $text = trim($update['message']['text'] ?? '');
        $command = strtoupper($text);
        
        // Simple test commands
        if ($command === '/START') {
            $keyboard = $telegram->inlineKeyboard([
                [
                    $telegram->inlineButton('🎫 Generate Voucher', 'menu:voucher'),
                    $telegram->inlineButton('📋 Harga Paket', 'menu:harga')
                ],
                [
                    $telegram->inlineButton('⚙️ MikroTik Menu', 'menu:mikrotik'),
                    $telegram->inlineButton('❓ Help', 'menu:help')
                ]
            ]);
            
            $msg = "🤖 *GEMBOK BOT*\n\n";
            $msg .= "✅ Webhook connected!\n\n";
            $msg .= "Selamat datang di Bot Admin Gembok!\n\n";
            $msg .= "Pilih menu di bawah atau ketik:\n";
            $msg .= "• /help - Lihat bantuan\n";
            $msg .= "• PING - Test MikroTik\n";
            $msg .= "• STATUS - Cek status";
            
            $telegram->sendMessage($chatId, $msg, 'Markdown', $keyboard);
        }
        elseif ($command === 'PING') {
            if ($mikrotik->isConnected()) {
                $telegram->sendMessage($chatId, "✅ *MIKROTIK ONLINE*\n\nKoneksi ke MikroTik berhasil!");
            } else {
                $telegram->sendMessage($chatId, "❌ *MIKROTIK OFFLINE*\n\nGagal koneksi");
            }
        }
        elseif ($command === '/HELP' || $command === 'HELP') {
            $msg = "🤖 *GEMBOK BOT - BANTUAN*\n\n";
            $msg .= "📋 *PERINTAH UMUM:*\n\n";
            $msg .= "🔌 `PING` - Test koneksi MikroTik\n";
            $msg .= "📊 `STATUS` - Cek status MikroTik\n\n";
            $msg .= "🎫 *VOUCHER:*\n\n";
            $msg .= "• `VOUCHER [profile]` - Random 5-digit\n";
            $msg .= "• `VCR [user] [profile]` - Custom user\n";
            $msg .= "• `MEMBER [user] [pass] [profile]` - Permanent\n\n";
            $msg .= "Ketik /start untuk menu interaktif";
            
            $telegram->sendMessage($chatId, $msg);
        }
        else {
            // Default: unknown command
            $telegram->sendMessage($chatId, "❓ Perintah tidak dikenali.\n\nKetik /help untuk bantuan.");
        }
    }
    
    // Handle callback queries
    if (isset($update['callback_query'])) {
        $callback = $update['callback_query'];
        $telegram->answerCallback($callback['id'], 'Processing...');
    }
    
} catch (Exception $e) {
    // Log error
    @file_put_contents(__DIR__ . '/writable/logs/telegram-error-' . date('Y-m-d') . '.log', 
        date('H:i:s') . " - " . $e->getMessage() . "\n", 
        FILE_APPEND
    );
}

// Always return OK to Telegram
header('Content-Type: application/json');
echo json_encode(['ok' => true]);
