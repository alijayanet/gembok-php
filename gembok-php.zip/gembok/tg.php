<?php
/**
 * Telegram Webhook - Debug Version with Extensive Logging
 */

ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

$logFile = __DIR__ . '/writable/logs/telegram-debug.log';

function logMsg($msg, $logFile) {
    @file_put_contents($logFile, date('Y-m-d H:i:s') . " - {$msg}\n", FILE_APPEND);
}

// GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode(['ok' => true, 'message' => 'Ready', 'time' => date('H:i:s')]);
    exit;
}

// POST request
$input = file_get_contents('php://input');
$update = json_decode($input, true);

logMsg("Received POST", $logFile);

if (!$update) {
    logMsg("No update data", $logFile);
    echo json_encode(['ok' => true]);
    exit;
}

// Get token
$botToken = null;
$envFile = __DIR__ . '/.env';

if (file_exists($envFile)) {
    $envContent = file_get_contents($envFile);
    if (preg_match('/TELEGRAM_BOT_TOKEN\s*=\s*(.+)/', $envContent, $matches)) {
        $botToken = trim($matches[1]);
        logMsg("Token loaded: " . substr($botToken, 0, 10) . "...", $logFile);
    }
}

if (!$botToken) {
    logMsg("NO TOKEN!", $logFile);
    echo json_encode(['ok' => false]);
    exit;
}

// Send function
function sendMsg($token, $chatId, $text, $logFile) {
    logMsg("Attempting to send to {$chatId}", $logFile);
    logMsg("Message: " . substr($text, 0, 50), $logFile);
    
    $url = "https://api.telegram.org/bot{$token}/sendMessage";
    $data = json_encode([
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'Markdown'
    ]);
    
    $opts = [
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/json\r\n",
            'content' => $data,
            'ignore_errors' => true
        ]
    ];
    
    $response = @file_get_contents($url, false, stream_context_create($opts));
    
    if ($response === false) {
        logMsg("FAILED to send (file_get_contents returned false)", $logFile);
        return false;
    }
    
    $result = json_decode($response, true);
    
    if (isset($result['ok']) && $result['ok']) {
        logMsg("SUCCESS sent to {$chatId}", $logFile);
        return true;
    } else {
        logMsg("ERROR from Telegram: " . ($result['description'] ?? 'Unknown'), $logFile);
        return false;
    }
}

// Handle message
if (isset($update['message']['text']) && isset($update['message']['chat']['id'])) {
    $chatId = $update['message']['chat']['id'];
    $text = trim($update['message']['text']);
    $cmd = strtoupper($text);
    
    logMsg("Command: {$text} from {$chatId}", $logFile);
    
    // Test simple response first
    if ($cmd === '/START' || $cmd === 'PING' || $cmd === '/HELP' || $cmd === 'HELP') {
        logMsg("Matched: HELP/START/PING", $logFile);
        
        $msg = "✅ *BOT WORKS*\n\n";
        $msg .= "Received: `{$text}`\n";
        $msg .= "Time: " . date('H:i:s') . "\n\n";
        $msg .= "*Commands:*\n";
        $msg .= "• VOUCHER [profile]\n";
        $msg .= "• VCR [user] [profile]\n";
        $msg .= "• MEMBER [user] [pass] [profile]";
        
        sendMsg($botToken, $chatId, $msg, $logFile);
    }
    
    // VOUCHER
    elseif (preg_match('/^VOUCHER\s+(\S+)$/i', $text, $m)) {
        logMsg("Matched: VOUCHER", $logFile);
        
        try {
            require_once __DIR__ . '/app/Services/ConfigService.php';
            require_once __DIR__ . '/app/Services/MikrotikService.php';
            
            $profile = $m[1];
            $username = (string)rand(10000, 99999);
            $password = $username;
            
            logMsg("Creating voucher: {$username} / {$profile}", $logFile);
            
            $mikrotik = new \App\Services\MikrotikService();
            $result = $mikrotik->addHotspotUser($username, $password, $profile, '24h');
            
            if ($result) {
                logMsg("MikroTik: SUCCESS", $logFile);
                $msg = "🎫 *VOUCHER*\n\n";
                $msg .= "👤 `{$username}`\n";
                $msg .= "🔑 `{$password}`\n";
                $msg .= "📦 {$profile}";
            } else {
                logMsg("MikroTik: FAILED - " . $mikrotik->getLastError(), $logFile);
                $msg = "❌ Error: " . $mikrotik->getLastError();
            }
            
            sendMsg($botToken, $chatId, $msg, $logFile);
            
        } catch (Exception $e) {
            logMsg("Exception: " . $e->getMessage(), $logFile);
            sendMsg($botToken, $chatId, "❌ Error: " . $e->getMessage(), $logFile);
        }
    }
    
    // VCR
    elseif (preg_match('/^VCR\s+(\S+)\s+(\S+)$/i', $text, $m)) {
        logMsg("Matched: VCR", $logFile);
        
        try {
            require_once __DIR__ . '/app/Services/ConfigService.php';
            require_once __DIR__ . '/app/Services/MikrotikService.php';
            
            $username = $m[1];
            $profile = $m[2];
            $password = $username . $profile;
            
            logMsg("Creating VCR: {$username} / {$profile}", $logFile);
            
            $mikrotik = new \App\Services\MikrotikService();
            $result = $mikrotik->addHotspotUser($username, $password, $profile, '24h');
            
            if ($result) {
                logMsg("MikroTik: SUCCESS", $logFile);
                $msg = "🎫 *VCR*\n\n";
                $msg .= "👤 `{$username}`\n";
                $msg .= "🔑 `{$password}`\n";
                $msg .= "📦 {$profile}";
            } else {
                logMsg("MikroTik: FAILED - " . $mikrotik->getLastError(), $logFile);
                $msg = "❌ Error: " . $mikrotik->getLastError();
            }
            
            sendMsg($botToken, $chatId, $msg, $logFile);
            
        } catch (Exception $e) {
            logMsg("Exception: " . $e->getMessage(), $logFile);
            sendMsg($botToken, $chatId, "❌ Error: " . $e->getMessage(), $logFile);
        }
    }
    
    // MEMBER
    elseif (preg_match('/^MEMBER\s+(\S+)\s+(\S+)\s+(\S+)$/i', $text, $m)) {
        logMsg("Matched: MEMBER", $logFile);
        
        try {
            require_once __DIR__ . '/app/Services/ConfigService.php';
            require_once __DIR__ . '/app/Services/MikrotikService.php';
            
            $username = $m[1];
            $password = $m[2];
            $profile = $m[3];
            
            logMsg("Creating MEMBER: {$username} / {$profile}", $logFile);
            
            $mikrotik = new \App\Services\MikrotikService();
            $result = $mikrotik->addHotspotUser($username, $password, $profile, '');
            
            if ($result) {
                logMsg("MikroTik: SUCCESS", $logFile);
                $msg = "👤 *MEMBER*\n\n";
                $msg .= "👤 `{$username}`\n";
                $msg .= "🔑 `{$password}`\n";
                $msg .= "📦 {$profile}\n";
                $msg .= "♾️ Permanent";
            } else {
                logMsg("MikroTik: FAILED - " . $mikrotik->getLastError(), $logFile);
                $msg = "❌ Error: " . $mikrotik->getLastError();
            }
            
            sendMsg($botToken, $chatId, $msg, $logFile);
            
        } catch (Exception $e) {
            logMsg("Exception: " . $e->getMessage(), $logFile);
            sendMsg($botToken, $chatId, "❌ Error: " . $e->getMessage(), $logFile);
        }
    }
    
    // Unknown
    else {
        logMsg("No match - sending help", $logFile);
        $msg = "❓ Perintah tidak dikenali.\n\nContoh:\n• VOUCHER 1JAM\n• VCR tamu 1JAM\n• MEMBER john pass 1BULAN";
        sendMsg($botToken, $chatId, $msg, $logFile);
    }
    
} else {
    logMsg("No message or chat_id in update", $logFile);
}

echo json_encode(['ok' => true]);
