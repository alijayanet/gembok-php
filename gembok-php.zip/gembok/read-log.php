<?php
// Read telegram log
$logFile = __DIR__ . '/writable/logs/telegram-debug.log';

if (file_exists($logFile)) {
    $content = file_get_contents($logFile);
    $lines = explode("\n", $content);
    $last20 = array_slice($lines, -20);
    
    header('Content-Type: text/plain');
    echo "=== LAST 20 LINES OF TELEGRAM LOG ===\n\n";
    echo implode("\n", $last20);
} else {
    echo "Log file not found: {$logFile}";
}
